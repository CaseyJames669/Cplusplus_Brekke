// File: constants.h
// Author: Casey Bladow
// Program: Asmt5
// Date 2-24-14

// Description: This file contains constant declarations

const int arraysize = 10;
const int sentinel = 0;