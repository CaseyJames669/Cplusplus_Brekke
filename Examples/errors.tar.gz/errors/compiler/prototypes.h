#include "circle.h"

void func(Circle&);


