#include "circle.h"
#include <iostream>
using namespace std;

void func()
{
   Circle c(5);
   cout << c.area() << endl;
}

