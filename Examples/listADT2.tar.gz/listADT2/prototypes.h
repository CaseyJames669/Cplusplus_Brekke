int menu();
void addItem(arrayListType&);
void deleteItem(arrayListType&);
int totalItems(arrayListType);
void totalOfItem(arrayListType);
