const int ARRAYMAX = 100;
