// File: constants.h
// Author: Casey Bladow
// Date: 3-4-14
// Class: CSIS 252
// Program: payroll

// Description
// The file contains the constant declarations

const int maxemployees = 100; // The maximum number of employees
